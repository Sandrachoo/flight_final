from datetime import datetime, timedelta
from serpapi import GoogleSearch
import csv
import json

# Your SerpApi API key
api_key = "3a3448c71341278aad0137354fd064fbf59511d1c7db081ea83f6ad511133455"

# Define the departure and arrival airports
departure_id = "VTE"
arrival_id = "SIN"

# Define the start and end dates for the search period
start_date = datetime(2024, 8, 1)
end_date = datetime(2024,8, 31) 

# Initialize a list to store the best flights
best_flights = []

# Utility function to serialize dictionaries for comparison
def serialize_dict(obj):
    if isinstance(obj, dict):
        return json.dumps(obj, sort_keys=True)
    return obj

# Loop through the dates and make a request for each date
while start_date <= end_date:
    page_num = 1  # Initialize page number
    seen_flights = set()  # Initialize a set to keep track of seen flights
    more_results = True  # Flag to check if more results are available

    while more_results:
        # Define the parameters for the Google Flights search
        params = {
            "engine": "google_flights",
            "departure_id": departure_id,
            "arrival_id": arrival_id,
            "currency": "USD",
            "outbound_date": start_date.strftime("%Y-%m-%d"),
            "type": 2,
            "api_key": api_key,
            "travel_class": 3,
            "stops": 2,
            "page": page_num  # Set the page number for pagination
        }

        # Create the GoogleSearch object
        search = GoogleSearch(params)

        # Run the search and get the results
        results = search.get_dict()

        # Debug: print the results to check the response structure
        print(f"Results for {start_date.strftime('%Y-%m-%d')} page {page_num}:")
        print(json.dumps(results, indent=2))  # Pretty print JSON results for better readability

        # Function to process flights and avoid duplicates
        def process_flights(flights, seen_flights, limit=None):
            count = 0
            for flight in flights:
                if limit and count >= limit:
                    break
                serialized_flight = serialize_dict(flight)
                if serialized_flight not in seen_flights:
                    seen_flights.add(serialized_flight)
                    best_flights.append(flight)
                    count += 1

        # Extract and process best flights from the search results
        if "best_flights" in results and results["best_flights"]:
            process_flights(results["best_flights"], seen_flights)

        # Extract and process other flights from the search results (limit to top 3)
        if "other_flights" in results and results["other_flights"]:
            process_flights(results["other_flights"], seen_flights, limit=3)

        # Determine if more results are available
        if not results.get("best_flights") and not results.get("other_flights"):
            more_results = False
        else:
            page_num += 1  # Move to the next page
            if page_num > 5:  # Safety check to prevent infinite loops
                more_results = False

    # Move to the next date
    start_date += timedelta(days=1)

# Define the field names for the CSV file
field_names = [
    'Departure Airport Name', 'Departure Airport ID', 'Departure Time',
    'Arrival Airport Name', 'Arrival Airport ID', 'Arrival Time',
    'Duration', 'Airline', 'Travel Class', 'Total Duration', 
    'Layover 1 Duration', 'Layover 1 Overnight',
    'Price'
]

# Write flight information to CSV file
with open('VTE_to_SIN_business_august.csv', mode='w', newline='') as file:
    writer = csv.DictWriter(file, fieldnames=field_names)
    writer.writeheader()
    for flight in best_flights:
        # Initialize layover details
        layover_1_duration = layover_1_name = layover_1_overnight = 'N/A'
        
        # Check for layovers
        if 'layovers' in flight and len(flight['layovers']) > 0:
            layover_1 = flight['layovers'][0]
            layover_1_duration = layover_1.get('duration', 'N/A')
            layover_1_name = layover_1.get('name', 'N/A')
            layover_1_overnight = layover_1.get('overnight', 'N/A')
            
        writer.writerow({
            'Departure Airport Name': flight['flights'][0]['departure_airport']['name'],
            'Departure Airport ID': flight['flights'][0]['departure_airport']['id'],
            'Departure Time': flight['flights'][0]['departure_airport']['time'],
            'Arrival Airport Name': flight['flights'][0]['arrival_airport']['name'],
            'Arrival Airport ID': flight['flights'][0]['arrival_airport']['id'],
            'Arrival Time': flight['flights'][0]['arrival_airport']['time'],
            'Duration': flight['flights'][0]['duration'],
            'Airline': flight['flights'][0]['airline'],
            'Travel Class': flight['flights'][0]['travel_class'],
            'Total Duration': flight['total_duration'],
            'Layover 1 Duration': layover_1_duration,
            'Layover 1 Overnight': layover_1_overnight,
            'Price': flight.get('price', 'N/A')  # Use 'N/A' if the price key is not present
        })

print("Flight information saved to VTE_to_SIN_business_august.csv")
